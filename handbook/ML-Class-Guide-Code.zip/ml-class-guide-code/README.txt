ML class guide: companion code (SkillNavora)
Each script builds its own synthetic data, so it runs anywhere without downloads.
Setup:  pip install numpy pandas scipy scikit-learn statsmodels
Run:    python c1_hypothesis_case.py   (and c2 ... c6)
Guide:  https://www.skillnavora.in/ml-class-guide.html
